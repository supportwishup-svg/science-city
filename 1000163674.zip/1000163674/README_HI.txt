SCIENCE CITY VOICE CONTROL — Android Studio source project

Features:
- BLE device name: science_city_automation
- Service UUID: 7b4a0001-9a3c-4d2e-8f61-1234567890ab
- Characteristic UUID: 7b4a0002-9a3c-4d2e-8f61-1234567890ab
- GPIO/relay control remains on ESP32 sketch: GPIO 4, 17, 18; Active HIGH.
- Manual buttons and Hindi/Hinglish + English speech recognition.

IMPORTANT:
This ZIP is Android Studio SOURCE CODE, not a prebuilt APK.
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s).
Install the generated APK on your Android phone.
If you use only ArduinoDroid, it cannot compile this Android app; use Android Studio on a computer or an Android IDE that supports Gradle Android projects.

ESP32:
Upload the BLE sketch with the exact same device name and UUIDs above. Its command callback must accept:
ON1, OFF1, ON2, OFF2, ON3, OFF3, ALL ON, ALL OFF.
If your ESP32 sketch expects other command strings, adjust the app's send()/parseCommand() or use matching sketch.

Phone:
1. Enable Bluetooth.
2. Open app and allow Nearby devices/Bluetooth and Microphone permissions.
3. Tap CONNECT ESP32 BLE.
4. Wait for Connected to ESP32.
5. Use buttons or press Hindi/Hinglish / English voice and speak a command.
Speech recognition may require internet or Google's speech services depending on the phone.
