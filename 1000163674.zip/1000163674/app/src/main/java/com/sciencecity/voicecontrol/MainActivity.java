package com.sciencecity.voicecontrol;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.speech.*;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private static final UUID SERVICE_UUID = UUID.fromString("7b4a0001-9a3c-4d2e-8f61-1234567890ab");
    private static final UUID CHAR_UUID = UUID.fromString("7b4a0002-9a3c-4d2e-8f61-1234567890ab");
    private static final String DEVICE_NAME = "science_city_automation";
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic commandChar;
    private TextView status, heard;
    private Button connectBtn, voiceHiBtn, voiceEnBtn;
    private boolean scanning = false;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        buildUi();
        BluetoothManager manager = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter = manager.getAdapter();
        requestNeededPermissions();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF4F7FB);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("SCIENCE CITY\nVOICE HOME AUTOMATION");
        title.setTextSize(24); title.setGravity(Gravity.CENTER); title.setTextColor(0xFF17365D);
        title.setPadding(0, 12, 0, 20); root.addView(title);

        status = new TextView(this); status.setText("Status: Disconnected");
        status.setTextSize(16); status.setGravity(Gravity.CENTER); status.setPadding(8, 12, 8, 12);
        root.addView(status);

        connectBtn = makeButton("CONNECT ESP32 BLE");
        connectBtn.setOnClickListener(v -> scanAndConnect()); root.addView(connectBtn);

        TextView tip = new TextView(this);
        tip.setText("Connect first, then use buttons or voice commands.");
        tip.setTextSize(14); tip.setGravity(Gravity.CENTER); tip.setPadding(0, 12, 0, 12); root.addView(tip);

        root.addView(commandButton("LIGHT 1  ON", "ON1"));
        root.addView(commandButton("LIGHT 1  OFF", "OFF1"));
        root.addView(commandButton("LIGHT 2  ON", "ON2"));
        root.addView(commandButton("LIGHT 2  OFF", "OFF2"));
        root.addView(commandButton("FAN  ON", "ON3"));
        root.addView(commandButton("FAN  OFF", "OFF3"));
        root.addView(commandButton("ALL  ON", "ALL ON"));
        root.addView(commandButton("ALL  OFF", "ALL OFF"));

        voiceHiBtn = makeButton(" HINDI / HINGLISH VOICE");
        voiceHiBtn.setOnClickListener(v -> listen("hi-IN")); root.addView(voiceHiBtn);
        voiceEnBtn = makeButton(" ENGLISH VOICE");
        voiceEnBtn.setOnClickListener(v -> listen("en-IN")); root.addView(voiceEnBtn);

        heard = new TextView(this); heard.setText("Voice command: �"); heard.setTextSize(15);
        heard.setPadding(8, 16, 8, 12); root.addView(heard);

        TextView commands = new TextView(this);
        commands.setText("Try: light one on/off, second light on/off, fan on/off, all on/off.\\nHindi: pehli light chalao/band karo, doosri light chalao/band karo, pankha chalao/band karo, sab chalao/sab band karo.");
        commands.setTextSize(14); commands.setPadding(8, 12, 8, 20); root.addView(commands);
        setContentView(scroll);
    }

    private Button commandButton(String label, String command) { Button b = makeButton(label); b.setOnClickListener(v -> send(command)); return b; }

    private Button makeButton(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(15);
        b.setAllCaps(false); b.setPadding(8, 8, 8, 8);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 5, 0, 5); b.setLayoutParams(lp);
        return b;
    }

    private void requestNeededPermissions() {
        ArrayList<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.RECORD_AUDIO);
        if (!p.isEmpty() && Build.VERSION.SDK_INT >= 23) requestPermissions(p.toArray(new String[0]), 100);
    }

    private void scanAndConnect() {
        if (adapter == null) { setStatus("Bluetooth not supported"); return; }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions(); setStatus("Allow Bluetooth permissions and tap connect again"); return;
        }
        if (!adapter.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 101); return;
        }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { setStatus("BLE scanner unavailable; turn Bluetooth on"); return; }
        if (scanning) { try { scanner.stopScan(scanCallback); } catch (Exception ignored) {} scanning = false; }
        setStatus("Searching for " + DEVICE_NAME + "...");
        scanning = true;
        try {
            scanner.startScan(scanCallback);
            handler.postDelayed(() -> {
                if (scanning) {
                    try { scanner.stopScan(scanCallback); } catch (Exception ignored) {}
                    scanning = false;
                    if (gatt == null || commandChar == null) setStatus("ESP32 not found. Check ESP32 power and BLE sketch.");
                }
            }, 12000);
        } catch (SecurityException e) { setStatus("Bluetooth permission missing"); }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            String name = null;
            try { name = d.getName(); } catch (SecurityException ignored) {}
            if (DEVICE_NAME.equals(name)) {
                try { scanner.stopScan(this); } catch (Exception ignored) {}
                scanning = false;
                setStatus("ESP32 found. Connecting...");
                gatt = d.connectGatt(MainActivity.this, false, gattCallback);
            }
        }
        @Override public void onScanFailed(int errorCode) { scanning = false; setStatus("BLE scan failed: " + errorCode); }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int statusCode, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                setStatus("Connected. Discovering services...");
                // Added a short delay to ensure stable connection before discovering services
                handler.postDelayed(() -> {
                    if (gatt != null) {
                        gatt.discoverServices();
                    }
                }, 600);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                commandChar = null;
                setStatus("Disconnected. Tap connect to retry.");
                try { g.close(); } catch (Exception ignored) {}
                if (gatt == g) gatt = null;
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int statusCode) {
            if (statusCode == BluetoothGatt.GATT_SUCCESS) {
                BluetoothGattService s = g.getService(SERVICE_UUID);
                commandChar = (s == null) ? null : s.getCharacteristic(CHAR_UUID);
                if (commandChar != null) setStatus("Connected to ESP32 ");
                else setStatus("Connected, but service/characteristic UUID mismatch. Upload matching BLE sketch.");
            } else {
                setStatus("Service discovery failed: " + statusCode);
            }
        }
        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic c, int statusCode) {
            if (statusCode == BluetoothGatt.GATT_SUCCESS) setStatus("Connected � command sent");
            else setStatus("Command write failed: " + statusCode);
        }
    };

    private void send(String command) {
        if (gatt == null || commandChar == null) { setStatus("Please connect ESP32 first"); return; }
        try {
            byte[] data = command.getBytes(StandardCharsets.UTF_8);
            if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeCharacteristic(commandChar, data, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            } else {
                commandChar.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                commandChar.setValue(data);
                gatt.writeCharacteristic(commandChar);
            }
            setStatus("Sending: " + command);
        } catch (SecurityException e) { setStatus("Bluetooth permission missing"); }
    }

    private void listen(String language) {
        if (gatt == null || commandChar == null) { setStatus("Connect ESP32 before voice control"); return; }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { setStatus("Speech recognition is not available on this phone"); return; }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, language.equals("hi-IN") ? "Command boliye" : "Say a command");
        SpeechRecognizer sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(new RecognitionListener() {
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String phrase = (matches == null || matches.isEmpty()) ? "" : matches.get(0);
                heard.setText("Voice command: " + phrase);
                String cmd = parseCommand(phrase);
                if (cmd == null) setStatus("Command samajh nahi aaya. Dobara boliye.");
                else send(cmd);
                sr.destroy();
            }
            @Override public void onError(int error) { setStatus("Voice recognition error. Try again."); sr.destroy(); }
            @Override public void onReadyForSpeech(Bundle params) { setStatus("Listening..."); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        sr.startListening(intent);
    }

    private String parseCommand(String phrase) {
        String s = phrase.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}\\s]", " ").replaceAll("\\s+", " ").trim();
        boolean on = has(s, "on", "start", "chalao", "chalu", "jalao", "jalaa do", " ", "kholo");
        boolean off = has(s, "off", "stop", "band", "bujhao", "bujha do", "", "");
        if (has(s, "all", "everything", "sab", "saari", "", "")) {
            if (on) return "ALL ON"; if (off) return "ALL OFF";
        }
        if (has(s, "fan", "pankha", "")) {
            if (on) return "ON3"; if (off) return "OFF3";
        }
        if (has(s, "second", "2", "two", "doosri", "dusri", "", "")) {
            if (has(s, "light", "bulb", "", "")) {
                if (on) return "ON2"; if (off) return "OFF2";
            }
        }
        if (has(s, "light", "bulb", "pehli", "first", "one", "1", "", "", "")) {
            if (on) return "ON1"; if (off) return "OFF1";
        }
        return null;
    }
    private boolean has(String s, String... words) { for (String w : words) if (s.contains(w)) return true; return false; }
    private void setStatus(String s) { runOnUiThread(() -> status.setText("Status: " + s)); }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if (scanner != null && scanning) scanner.stopScan(scanCallback); } catch (Exception ignored) {}
        try { if (gatt != null) { gatt.disconnect(); gatt.close(); } } catch (Exception ignored) {}
    }
}